var x = document.getElementById("login");
var y = document.getElementById("register");
var z = document.getElementById("btn");

function register() {
    x.style.left = "-200px";
    y.style.left = "190px";
    z.style.left = "110px";
}

function login() {
    x.style.left = "190px";
    y.style.left = "-500px";
    z.style.left = "0";
}